#pragma once

#include <string>

class Member {
public:
    Member(std::string id, std::string name, std::string email);

    const std::string& id() const;
    const std::string& name() const;
    const std::string& email() const;

private:
    std::string id_;
    std::string name_;
    std::string email_;
};
