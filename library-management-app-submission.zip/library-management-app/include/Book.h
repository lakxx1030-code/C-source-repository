#pragma once

#include <string>

class Book {
public:
    Book(std::string id, std::string title, std::string author, std::string category);

    const std::string& id() const;
    const std::string& title() const;
    const std::string& author() const;
    const std::string& category() const;
    bool isAvailable() const;
    void setAvailable(bool available);

private:
    std::string id_;
    std::string title_;
    std::string author_;
    std::string category_;
    bool available_{true};
};
