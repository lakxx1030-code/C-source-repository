#pragma once

#include <string>

namespace input {
std::string requiredText(const std::string& prompt);
int menuChoice(const std::string& prompt, int minimum, int maximum);
bool containsReservedCharacter(const std::string& text);
}
