#pragma once

#include "Book.h"
#include "Loan.h"
#include "Member.h"

#include <string>
#include <vector>

class Library {
public:
    explicit Library(std::string dataDirectory);

    bool load(std::string& message);
    bool save(std::string& message) const;

    bool addBook(const Book& book, std::string& message);
    bool addMember(const Member& member, std::string& message);
    bool issueBook(const std::string& bookId, const std::string& memberId, const std::string& date, std::string& message);
    bool returnBook(const std::string& bookId, const std::string& date, std::string& message);

    std::vector<const Book*> searchBooks(const std::string& query) const;
    const std::vector<Book>& books() const;
    const std::vector<Member>& members() const;
    std::vector<const Loan*> activeLoans() const;
    const Book* findBook(const std::string& id) const;
    const Member* findMember(const std::string& id) const;

private:
    std::string dataDirectory_;
    std::vector<Book> books_;
    std::vector<Member> members_;
    std::vector<Loan> loans_;

    Book* findBookForUpdate(const std::string& id);
    void refreshAvailability();
};
