#pragma once

#include <string>

class Loan {
public:
    Loan(std::string bookId, std::string memberId, std::string issuedOn, std::string returnedOn = "");

    const std::string& bookId() const;
    const std::string& memberId() const;
    const std::string& issuedOn() const;
    const std::string& returnedOn() const;
    bool isActive() const;
    void markReturned(const std::string& date);

private:
    std::string bookId_;
    std::string memberId_;
    std::string issuedOn_;
    std::string returnedOn_;
};
