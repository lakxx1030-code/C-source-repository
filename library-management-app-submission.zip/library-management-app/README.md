# Community Library Manager

A beginner-friendly, menu-driven C++11 application that manages books, members, and loans. It uses classes and private fields for encapsulation, `std::vector` collections for records, and local text files for persistence.

## What it does

- Lists and searches books by ID, title, author, or category
- Registers books and members with duplicate-ID protection
- Issues only available books to registered members
- Returns active loans and makes the related book available again
- Saves after every change and reloads the same records at startup
- Validates blank text, invalid menu input, and the reserved persistence character (`|`)

## Project structure

```
library-management-app/
├── include/             # Class interfaces and input helpers
├── src/                 # Class implementations and application menu
├── data/                # Safe local persistence files and fictional seed data
├── CMakeLists.txt       # Build configuration
├── class-diagram.md     # Mermaid UML-style class diagram
└── README.md            # This guide
```

## Build and run

Run these commands from this folder.

### With g++

```powershell
g++ -std=c++11 -Wall -Wextra -Wpedantic -I include (Get-ChildItem src\*.cpp | ForEach-Object FullName) -o library_manager.exe
.\library_manager.exe
```

### With CMake

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\library_manager.exe
```

If your CMake generator writes executables directly into `build`, run `.\build\library_manager.exe` instead.

## Sample data and persistence

The `data/` folder starts with five fictional books, three members, and two loan records. The application reads these files on startup:

| File | Stored records |
| --- | --- |
| `books.txt` | ID, title, author, category |
| `members.txt` | ID, name, email |
| `loans.txt` | Book ID, member ID, issue date, return date |

The pipe character separates fields, so the application rejects it in typed input. Saving writes a temporary file first, keeps the previous file as a short-lived backup during replacement, and restores that backup if replacement fails.

## Class responsibilities

- **Book**: owns book details and availability state.
- **Member**: owns member identity and contact data.
- **Loan**: owns the relationship between one book, one member, and the loan dates.
- **Library**: owns the collections, enforces issuing/returning rules, performs searches, and saves/loads records.

See [class-diagram.md](class-diagram.md) for the diagram.

## Passing checklist

- [x] `Book`, `Member`, and `Loan` classes have separate responsibilities and private data.
- [x] Issue, return, search, and availability behaviour are implemented.
- [x] Records persist safely to the local `data/` files and reload when the application starts.
- [x] The project is multi-file and includes a diagram, sample data, and build instructions.

## Submission

Publish this single `library-management-app` folder as a public or view-only repository, then submit that repository URL. Everything a reviewer needs—the source, diagram, sample data, and README—is in the same folder.

For a concise proof artifact, see `outputs/sample-run.txt`.
