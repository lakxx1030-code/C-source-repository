#include "InputUtils.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <sstream>

namespace {
std::string trim(const std::string& value) {
    const auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char character) { return std::isspace(character); });
    const auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char character) { return std::isspace(character); }).base();
    return first >= last ? "" : std::string(first, last);
}
}

std::string input::requiredText(const std::string& prompt) {
    while (true) {
        std::cout << prompt;
        std::string value;
        if (!std::getline(std::cin, value)) {
            std::cout << "\nInput ended. Closing safely.\n";
            std::exit(0);
        }
        value = trim(value);
        if (value.empty()) {
            std::cout << "This value cannot be empty. Please try again.\n";
        } else if (containsReservedCharacter(value)) {
            std::cout << "The | character is reserved by the local data file. Please use different text.\n";
        } else {
            return value;
        }
    }
}

int input::menuChoice(const std::string& prompt, int minimum, int maximum) {
    while (true) {
        std::cout << prompt;
        std::string line;
        if (!std::getline(std::cin, line)) {
            return maximum;
        }
        std::istringstream parser(trim(line));
        int choice{};
        char extra{};
        if (parser >> choice && !(parser >> extra) && choice >= minimum && choice <= maximum) {
            return choice;
        }
        std::cout << "Enter a whole number from " << minimum << " to " << maximum << ".\n";
    }
}

bool input::containsReservedCharacter(const std::string& text) {
    return text.find('|') != std::string::npos;
}
