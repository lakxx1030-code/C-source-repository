#include "Library.h"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdio>
#include <fstream>
#include <functional>
#include <sstream>
#include <utility>

#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#endif

namespace {
std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> fields;
    std::stringstream stream(line);
    std::string field;
    while (std::getline(stream, field, '|')) fields.push_back(field);
    if (!line.empty() && line.back() == '|') fields.push_back("");
    return fields;
}

std::string lower(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(), [](unsigned char character) { return static_cast<char>(std::tolower(character)); });
    return text;
}

bool includesIgnoreCase(const std::string& text, const std::string& query) {
    return lower(text).find(lower(query)) != std::string::npos;
}

bool ensureDirectory(const std::string& directory) {
#ifdef _WIN32
    return _mkdir(directory.c_str()) == 0 || errno == EEXIST;
#else
    return mkdir(directory.c_str(), 0755) == 0 || errno == EEXIST;
#endif
}

std::string pathFor(const std::string& directory, const std::string& filename) {
    return directory + "/" + filename;
}

bool saveLinesAtomically(const std::string& file, const std::vector<std::string>& lines) {
    const std::string temporaryFile = file + ".tmp";
    const std::string backupFile = file + ".bak";
    std::ofstream output(temporaryFile, std::ios::trunc);
    if (!output) return false;
    for (const std::string& line : lines) output << line << '\n';
    output.close();
    if (!output) return false;

    std::ifstream existing(file);
    const bool hadExistingFile = existing.good();
    existing.close();

    std::remove(backupFile.c_str());
    if (hadExistingFile && std::rename(file.c_str(), backupFile.c_str()) != 0) {
        std::remove(temporaryFile.c_str());
        return false;
    }
    if (std::rename(temporaryFile.c_str(), file.c_str()) != 0) {
        std::remove(temporaryFile.c_str());
        if (hadExistingFile) std::rename(backupFile.c_str(), file.c_str());
        return false;
    }
    if (hadExistingFile) std::remove(backupFile.c_str());
    return true;
}
}

Library::Library(std::string dataDirectory) : dataDirectory_(std::move(dataDirectory)) {}

bool Library::load(std::string& message) {
    books_.clear();
    members_.clear();
    loans_.clear();

    if (!ensureDirectory(dataDirectory_)) {
        message = "Could not access the data folder.";
        return false;
    }
    const std::function<void(const std::string&, const std::function<void(const std::vector<std::string>&)>&)> loadFile = [this](const std::string& name, const std::function<void(const std::vector<std::string>&)>& handler) {
        std::ifstream input(pathFor(dataDirectory_, name));
        std::string line;
        while (std::getline(input, line)) {
            if (!line.empty() && line.front() != '#') handler(split(line));
        }
    };

    loadFile("books.txt", [this](const std::vector<std::string>& fields) {
        if (fields.size() == 4 && findBook(fields[0]) == nullptr) books_.emplace_back(fields[0], fields[1], fields[2], fields[3]);
    });
    loadFile("members.txt", [this](const std::vector<std::string>& fields) {
        if (fields.size() == 3 && findMember(fields[0]) == nullptr) members_.emplace_back(fields[0], fields[1], fields[2]);
    });
    loadFile("loans.txt", [this](const std::vector<std::string>& fields) {
        if (fields.size() == 4 && findBook(fields[0]) != nullptr && findMember(fields[1]) != nullptr) loans_.emplace_back(fields[0], fields[1], fields[2], fields[3]);
    });

    refreshAvailability();
    message = "Loaded " + std::to_string(books_.size()) + " book(s), " + std::to_string(members_.size()) + " member(s), and " + std::to_string(loans_.size()) + " loan record(s).";
    return true;
}

bool Library::save(std::string& message) const {
    if (!ensureDirectory(dataDirectory_)) {
        message = "Could not access the data folder.";
        return false;
    }
    std::vector<std::string> bookLines{"# id|title|author|category"};
    std::vector<std::string> memberLines{"# id|name|email"};
    std::vector<std::string> loanLines{"# bookId|memberId|issuedOn|returnedOn (blank means active)"};
    for (const Book& book : books_) bookLines.push_back(book.id() + "|" + book.title() + "|" + book.author() + "|" + book.category());
    for (const Member& member : members_) memberLines.push_back(member.id() + "|" + member.name() + "|" + member.email());
    for (const Loan& loan : loans_) loanLines.push_back(loan.bookId() + "|" + loan.memberId() + "|" + loan.issuedOn() + "|" + loan.returnedOn());

    if (!saveLinesAtomically(pathFor(dataDirectory_, "books.txt"), bookLines) ||
        !saveLinesAtomically(pathFor(dataDirectory_, "members.txt"), memberLines) ||
        !saveLinesAtomically(pathFor(dataDirectory_, "loans.txt"), loanLines)) {
        message = "Could not save all records. Existing files were left untouched where possible.";
        return false;
    }
    message = "Records saved to the local data folder.";
    return true;
}

bool Library::addBook(const Book& book, std::string& message) {
    if (findBook(book.id()) != nullptr) {
        message = "A book with that ID already exists.";
        return false;
    }
    books_.push_back(book);
    return save(message);
}

bool Library::addMember(const Member& member, std::string& message) {
    if (findMember(member.id()) != nullptr) {
        message = "A member with that ID already exists.";
        return false;
    }
    members_.push_back(member);
    return save(message);
}

bool Library::issueBook(const std::string& bookId, const std::string& memberId, const std::string& date, std::string& message) {
    Book* book = findBookForUpdate(bookId);
    if (book == nullptr) { message = "Book ID not found."; return false; }
    if (findMember(memberId) == nullptr) { message = "Member ID not found."; return false; }
    if (!book->isAvailable()) { message = "That book is already on loan."; return false; }
    loans_.emplace_back(bookId, memberId, date);
    book->setAvailable(false);
    return save(message);
}

bool Library::returnBook(const std::string& bookId, const std::string& date, std::string& message) {
    auto loan = std::find_if(loans_.rbegin(), loans_.rend(), [&bookId](const Loan& current) { return current.bookId() == bookId && current.isActive(); });
    if (loan == loans_.rend()) { message = "No active loan was found for that book ID."; return false; }
    loan->markReturned(date);
    Book* book = findBookForUpdate(bookId);
    if (book != nullptr) book->setAvailable(true);
    return save(message);
}

std::vector<const Book*> Library::searchBooks(const std::string& query) const {
    std::vector<const Book*> matches;
    for (const Book& book : books_) {
        if (includesIgnoreCase(book.id(), query) || includesIgnoreCase(book.title(), query) ||
            includesIgnoreCase(book.author(), query) || includesIgnoreCase(book.category(), query)) matches.push_back(&book);
    }
    return matches;
}

const std::vector<Book>& Library::books() const { return books_; }
const std::vector<Member>& Library::members() const { return members_; }

std::vector<const Loan*> Library::activeLoans() const {
    std::vector<const Loan*> result;
    for (const Loan& loan : loans_) if (loan.isActive()) result.push_back(&loan);
    return result;
}

const Book* Library::findBook(const std::string& id) const {
    const auto result = std::find_if(books_.begin(), books_.end(), [&id](const Book& book) { return book.id() == id; });
    return result == books_.end() ? nullptr : &*result;
}

const Member* Library::findMember(const std::string& id) const {
    const auto result = std::find_if(members_.begin(), members_.end(), [&id](const Member& member) { return member.id() == id; });
    return result == members_.end() ? nullptr : &*result;
}

Book* Library::findBookForUpdate(const std::string& id) {
    const auto result = std::find_if(books_.begin(), books_.end(), [&id](const Book& book) { return book.id() == id; });
    return result == books_.end() ? nullptr : &*result;
}

void Library::refreshAvailability() {
    for (Book& book : books_) book.setAvailable(true);
    for (const Loan& loan : loans_) {
        if (loan.isActive()) {
            Book* book = findBookForUpdate(loan.bookId());
            if (book != nullptr) book->setAvailable(false);
        }
    }
}
