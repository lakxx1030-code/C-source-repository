#include "Member.h"

#include <utility>

Member::Member(std::string id, std::string name, std::string email)
    : id_(std::move(id)), name_(std::move(name)), email_(std::move(email)) {}

const std::string& Member::id() const { return id_; }
const std::string& Member::name() const { return name_; }
const std::string& Member::email() const { return email_; }
