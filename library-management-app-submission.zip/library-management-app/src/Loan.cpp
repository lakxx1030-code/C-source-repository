#include "Loan.h"

#include <utility>

Loan::Loan(std::string bookId, std::string memberId, std::string issuedOn, std::string returnedOn)
    : bookId_(std::move(bookId)), memberId_(std::move(memberId)), issuedOn_(std::move(issuedOn)), returnedOn_(std::move(returnedOn)) {}

const std::string& Loan::bookId() const { return bookId_; }
const std::string& Loan::memberId() const { return memberId_; }
const std::string& Loan::issuedOn() const { return issuedOn_; }
const std::string& Loan::returnedOn() const { return returnedOn_; }
bool Loan::isActive() const { return returnedOn_.empty(); }
void Loan::markReturned(const std::string& date) { returnedOn_ = date; }
