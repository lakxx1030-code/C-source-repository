#include "InputUtils.h"
#include "Library.h"

#include <ctime>
#include <iomanip>
#include <iostream>

namespace {
std::string today() {
    const std::time_t now = std::time(nullptr);
    const std::tm* localTime = std::localtime(&now);
    if (localTime == nullptr) return "unknown-date";
    char buffer[11];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d", localTime);
    return buffer;
}

void printMenu() {
    std::cout << "\n=======================================\n"
              << "          COMMUNITY LIBRARY\n"
              << "=======================================\n"
              << "1. List books\n2. Search books\n3. Add a book\n4. List members\n5. Register a member\n"
              << "6. Issue a book\n7. Return a book\n8. List active loans\n9. Save and exit\n"
              << "---------------------------------------\n";
}

void printBooks(const std::vector<const Book*>& books) {
    if (books.empty()) { std::cout << "No matching books found.\n"; return; }
    std::cout << std::left << std::setw(10) << "ID" << std::setw(30) << "Title" << std::setw(24) << "Author" << "Status\n";
    std::cout << std::string(78, '-') << "\n";
    for (const Book* book : books) {
        std::cout << std::left << std::setw(10) << book->id() << std::setw(30) << book->title().substr(0, 29)
                  << std::setw(24) << book->author().substr(0, 23) << (book->isAvailable() ? "Available" : "On loan") << "\n";
    }
}

void printAllBooks(const Library& library) {
    std::vector<const Book*> books;
    for (const Book& book : library.books()) books.push_back(&book);
    printBooks(books);
}
}

int main() {
    Library library("data");
    std::string message;
    library.load(message);
    std::cout << "Welcome to the Community Library Manager.\n" << message << "\n";

    while (true) {
        printMenu();
        switch (input::menuChoice("Choose an option (1-9): ", 1, 9)) {
            case 1: printAllBooks(library); break;
            case 2: printBooks(library.searchBooks(input::requiredText("Search title, author, category, or ID: "))); break;
            case 3: {
                Book book(input::requiredText("Book ID: "), input::requiredText("Title: "), input::requiredText("Author: "), input::requiredText("Category: "));
                library.addBook(book, message); std::cout << message << "\n"; break;
            }
            case 4: {
                if (library.members().empty()) { std::cout << "No members registered.\n"; break; }
                std::cout << std::left << std::setw(10) << "ID" << std::setw(28) << "Name" << "Email\n";
                for (const Member& member : library.members()) std::cout << std::left << std::setw(10) << member.id() << std::setw(28) << member.name() << member.email() << "\n";
                break;
            }
            case 5: {
                Member member(input::requiredText("Member ID: "), input::requiredText("Name: "), input::requiredText("Email: "));
                library.addMember(member, message); std::cout << message << "\n"; break;
            }
            case 6: {
                const std::string bookId = input::requiredText("Book ID to issue: ");
                const std::string memberId = input::requiredText("Member ID: ");
                library.issueBook(bookId, memberId, today(), message); std::cout << message << "\n"; break;
            }
            case 7: library.returnBook(input::requiredText("Book ID to return: "), today(), message); std::cout << message << "\n"; break;
            case 8: {
                const auto loans = library.activeLoans();
                if (loans.empty()) { std::cout << "No active loans.\n"; break; }
                std::cout << std::left << std::setw(12) << "Book ID" << std::setw(12) << "Member ID" << "Issued on\n";
                for (const Loan* loan : loans) std::cout << std::left << std::setw(12) << loan->bookId() << std::setw(12) << loan->memberId() << loan->issuedOn() << "\n";
                break;
            }
            case 9:
                library.save(message); std::cout << message << "\nGoodbye!\n"; return 0;
        }
    }
}
