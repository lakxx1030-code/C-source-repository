#include "Book.h"

#include <utility>

Book::Book(std::string id, std::string title, std::string author, std::string category)
    : id_(std::move(id)), title_(std::move(title)), author_(std::move(author)), category_(std::move(category)) {}

const std::string& Book::id() const { return id_; }
const std::string& Book::title() const { return title_; }
const std::string& Book::author() const { return author_; }
const std::string& Book::category() const { return category_; }
bool Book::isAvailable() const { return available_; }
void Book::setAvailable(bool available) { available_ = available; }
