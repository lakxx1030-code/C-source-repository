# Class Diagram

```mermaid
classDiagram
    class Book {
        -string id_
        -string title_
        -string author_
        -string category_
        -bool available_
        +isAvailable() bool
        +setAvailable(bool) void
    }
    class Member {
        -string id_
        -string name_
        -string email_
    }
    class Loan {
        -string bookId_
        -string memberId_
        -string issuedOn_
        -string returnedOn_
        +isActive() bool
        +markReturned(string) void
    }
    class Library {
        -vector~Book~ books_
        -vector~Member~ members_
        -vector~Loan~ loans_
        +load() bool
        +save() bool
        +issueBook() bool
        +returnBook() bool
        +searchBooks() vector
    }
    Library "1" *-- "many" Book : owns
    Library "1" *-- "many" Member : owns
    Library "1" *-- "many" Loan : owns
    Loan --> Book : identifies by book ID
    Loan --> Member : identifies by member ID
```

`Library` is the coordinator. `Book`, `Member`, and `Loan` keep their own state private and expose only the operations the rest of the program needs.
